This project is for [Tan's Huge Trees](https://legacy.curseforge.com/minecraft/mc-mods/tan-huge-trees) mod, it's separate pack from main mod. Contains generated tree files, their presets and default settings. You can manual install the pack by extract the ZIP to `config/THT/custom/tree_packs`.

This project also be an example pack for people who want to create own tree pack.